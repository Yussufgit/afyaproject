<?php
$conn = mysqli_connect("localhost","root","","healthcare");   
        if (mysqli_connect_error()) {
            die ("Database Connection Error");
        }
?>